from django.shortcuts import render
from rest_framework import viewsets
from rest_framework import permissions
from.serializers import exams
from.models import exam
# Create your views here.

class examviewset(viewsets.ModelViewSet):
	queryset=exam.objects.all()
	serializer_class=exams
	permission_classess=[permissions.IsAuthenticated]