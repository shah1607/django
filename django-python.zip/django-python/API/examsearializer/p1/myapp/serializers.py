#from django.contrib import admin
from rest_framework import serializers
from.models import exam
# Register your models here.
class exams(serializers.HyperlinkedModelSerializer):
	class Meta:
		model=exam
		fields='__all__'