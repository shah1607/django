#from django.contrib.auth.models import  productmodel
from rest_framework import serializers
from.models import productmodel

# Create your views here.
class productserializer(serializers.HyperlinkedModelSerializer):
	class Meta:
		model=productmodel
		fields='__all__'
