from django.db import models

# Create your models here.
class productmodel(models.Model):
	pname=models.CharField(max_length=50)
	pprice=models.IntegerField()
	pcategories=models.CharField(max_length=50)
	pdesc=models.CharField(max_length=50)

	def __str__(self):
		return self.pname