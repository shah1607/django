from django.shortcuts import render

# Create your views here.
from rest_framework import viewsets
from rest_framework import permissions
from.serializers import productserializer
from.models import productmodel

class productviewset(viewsets.ModelViewSet):
	queryset=productmodel.objects.all()
	serializer_class=productserializer
	permission_classes=[permissions.IsAuthenticated]
