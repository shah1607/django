from django.shortcuts import render,redirect
from.models import product
from django.http import HttpResponse,HttpRequest
# Create your views here.
def index(request):
	return render(request,'index.html')

def indexadd(request):
	pname=request.GET['pname']
	products=product(pname=pname)
	products.save()
	return redirect(display)

def display(request):
	data=product.objects.all()
	return render(request,'display.html',{'data':data})

def update(request):
	id=request.GET['id']
	data=product.objects.get(id=id)
	return render(request,'update.html',{'data':data})

def updatedata(request):
	id=request.GET['id']
	data=product.objects.get(id=id)
	data.pname=request.GET['pname']
	data.save()
	data=product.objects.all()
	return redirect(display)
	#return render(request,'display.html',{'data':data})

def delete(request):
	id=request.GET['id']
	data=product.objects.get(id=id)
	data.delete()
	return redirect(display)