from django.shortcuts import render
from.models import signup
from.forms import signupform
# Create your views here.
def signups(request):
	if request.method=="post":
		signup_form=signupform(request.post)
		if signup_form.is_valid():
			signup_form.save()

	signup_form=signupform()
	data=signup.objects.all()
	context={'data':data,'signup_form':signup_form}
	return render(request,'home.html',context)







# from.models import signup
# from.forms import signupform

# def home(request):
# 	if request.method=="POST"
# 		formss=signupform(request.post)
# 			if formss.is_valid():
# 			formss.save()

# 	formss=signupform()
# 	data=signup.objects.all()
# 	context={'data':data,'formss':formss}
# 	return render(request,'home.html',context)