from django.apps import AppConfig


class P1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'p1'
