from django import forms
from.models import usermodel,project

# Create your tests here.
class userform(forms.ModelForm):
	class Meta:
		model=usermodel
		fields='__all__'

class projectform(forms.ModelForm):
	class Meta:
		model=project
		fields='__all__'