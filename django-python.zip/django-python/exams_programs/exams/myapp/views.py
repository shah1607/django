from django.shortcuts import render
from.models import usermodel,project
from.forms import *
# Create your views here.
def home(request):
	if request.method=='POST':
		uform=userform(request.POST)
		if uform.is_valid():
			uform.save()
		return redirect(home)

	uform=userform()
	data=usermodel.objects.all()
	context={'uform':uform,'data':data}
	return render(request,'home.html',context)

