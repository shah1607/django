from django.db import models

# Create your models here.
class project(models.Model):
	c1=models.CharField(max_length=50)

	def __str__(self):
		return self.c1

class usermodel(models.Model):
	uname=models.CharField(max_length=50)
	pwd=models.CharField(max_length=50)

	def __str__(self):
		return self.uname