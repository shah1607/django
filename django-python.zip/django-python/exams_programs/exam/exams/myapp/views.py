from django.shortcuts import render,redirect
from django.http import HttpRequest,HttpResponse
from myapp.models import exm
# Create your views here.
def form(request):
	return render(request,'form.html')

def savedata(request):
	uname=request.GET.get("uname")
	lname=request.GET.get("lname")
	email=request.GET.get("email")
	p=exm(uname=uname,lname=lname,email=email)
	p.save()
	data=exm.objects.all()
	return render(request,'save.html',{'data':data})
def saves(request):
	data=exm.objects.all()
	return render(request,'save.html',{'data':data})

def update(request):
	id=request.GET['id']
	data=exm.objects.get(id=id)
	return render(request,'update.html',{'data':data})
def updatedata(request):
	id=request.GET['id']
	data=exm.objects.get(id=id)
	data.uname=request.GET['uname']
	data.lname=request.GET['lname']
	data.email=request.GET['email']

	data.save()
	data=exm.objects.all()
	return redirect(saves)

def delete(request):
	id=request.GET['id']
	data=exm.objects.get(id=id)
	data.delete()
	data=exm.objects.all()
	return render(request,'save.html',{'data':data})