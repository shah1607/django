from django.contrib import admin
from.models import exm

# Register your models here.
admin.site.register(exm);