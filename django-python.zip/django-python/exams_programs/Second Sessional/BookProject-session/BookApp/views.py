from django.shortcuts import render,get_object_or_404,redirect
from .models import BookModel
from .forms import BookForm,LoginForm

# Create your views here.

def displayall(request):
	username=request.session.get('username')
	books= BookModel.objects.all()
	return render(request,'display.html',{'books':books,'username':username})

def display(request,id):
	username=request.session.get('username')
	if username:
		book= get_object_or_404(BookModel,pk=id)
		return render(request,'details.html',{'book':book})
	return redirect(login)

def edit(request,id):
	book= get_object_or_404(BookModel,pk=id)
	if request.method=='POST':
		form = BookForm(request.POST, instance=book)
		form.save()
		return redirect(displayall)
	else:
		form= BookForm(instance=book)
	return render(request,'edit.html',{'form':form})

def delete(request,id):
	book= get_object_or_404(BookModel,pk=id)
	book.delete()
	return render(request,'delete.html')

def login(request):
	if request.method=='POST':
		form=LoginForm(data=request.POST)
		form.is_valid()
		username = form.cleaned_data.get('username')
		password = form.cleaned_data.get('password')
		if username=='Admin':
			request.session['username']=username
			print(username)
			return redirect(displayall)
	else:
		form =LoginForm()
		return render(request,'login.html',{'form':form})
def logout(request):
	del request.session['username']
	
	return redirect(login)
