from django.shortcuts import render,get_object_or_404,redirect
from .models import BookModel
from .forms import BookForm
# Create your views here.
def displayall(request):
	book=BookModel.objects.all()
	return render(request,'display.html',{'book':book})

def display(request,id):
	book=get_object_or_404(BookModel,pk=id)
	return render(request,'details.html',{'book':book}) 

def edit(request,id):
	book=get_object_or_404(BookModel,pk=id)#primarykey,bookmodel
	
	if request.method=='POST':
		form=BookForm(request.POST,instance=book)
		form.save()
		return redirect(displayall)
	else:
		form=BookForm(instance=book)
		return render(request,'edit.html',{'form':form})

def delete(request,id):
	book=get_object_or_404(BookModel,pk=id)
	book.delete()
	return render(request,'delete.html')