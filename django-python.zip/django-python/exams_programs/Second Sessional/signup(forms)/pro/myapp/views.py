from django.shortcuts import render,redirect
from .models import User
from .forms import *
from django.contrib.auth import authenticate



# Create your views here.

def homepage(request):
    if request.method=="POST":
        userform=signup(request.POST)
        if userform.is_valid():
            userform.save()

        return redirect(homepage)
    
    userform=signup()
    user=User.objects.all()
    context={'userform':userform,'user':user}
    return render(request,'homepage.html',context)

def login(request):
    if request.method == "POST":
        Login = loginform(request.POST)
        if Login.is_valid():
            username = Login.cleaned_data.get('username')
            password = Login.cleaned_data.get('password')
            
            res=User.objects.filter(username=username, password=password)

            if len(res)>0:
                return render(request,'loginchck.html')
        
    Login=loginform()
    context={'Login':Login}
    return render(request,'login.html',context)

def loginchck(request):
    return render(request,'loginchck.html')
    

