from django import forms
from .models import User

# Register your models here.
class signup(forms.ModelForm):
    class Meta:
        model=User
        fields='__all__'

class loginform(forms.ModelForm):
    class Meta:
        model=User
        fields=['username','password']