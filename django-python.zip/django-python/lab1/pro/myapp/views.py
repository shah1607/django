from django.shortcuts import render
from django.http import HttpRequest,HttpResponse
from myapp.models import signup
# Create your views here.
def signups(request):
	return render(request,'signup.html')

def savedata(request):
	fname=request.GET.get('fname')
	lname=request.GET.get('lname')
	email=request.GET.get('email')
	uname=request.GET.get('uname')
	psw=request.GET.get('psw')
	cpass=request.GET.get('cpass')
	if(psw!=cpass):
		return HttpResponse("<h1>Password does not match</h1>")
	else:
		p=signup(fname=fname,lname=lname,email=email,uname=uname,psw=psw)
		p.save()
		return render(request,'login.html')

def login(request):
	return render(request,'login.html')


def check(request):
	uname=request.GET.get('uname')
	psw=request.GET.get('psw')
	data=signup.objects.all()
	for d in data:
		if(d.uname==uname and d.psw==psw):
			return render(request,'saved.html',{'Name':d.uname,'data':data})

	return render(request,'login.html')
		


def edit(request):
	id=request.GET['id']
	data=signup.objects.get(id=id)
	return render(request,'edit.html',{'data':data})
	

def update(request):
	id=request.GET.get('id')
	print(id)
	print('Hello')
	fname=request.GET.get('fname')
	lname=request.GET.get('lname')
	email=request.GET.get('email')
	uname=request.GET.get('uname')
	psw=request.GET.get('psw')
	cpass=request.GET.get('cpass')
	data=signup.objects.get(id=id)

	if(psw==cpass):
		
		data.fname=fname
		data.lname=lname
		data.email=email
		data.uname=uname
		data.psw=psw
		data.cpass=cpass
		data.save()
		data=signup.objects.all()
		return render(request,'saved.html',{'data':data})

	else:

		return render(request,'edit.html')


def delete(request):
	id=request.GET['id']
	data=signup.objects.get(id=id)
	data.delete()
	data=signup.objects.all()
	return render(request,'saved.html',{'data':data})