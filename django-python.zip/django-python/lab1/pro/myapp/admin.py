from django.contrib import admin
from.models import signup
# Register your models here.
admin.site.register(signup)