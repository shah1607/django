from django.contrib import admin
from.models import products
# Register your models here.
admin.site.register(products)