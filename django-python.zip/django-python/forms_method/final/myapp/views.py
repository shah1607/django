from django.shortcuts import render,redirect,get_object_or_404
from.forms import productform
from.models import products
# Create your views here.

def home(request):
	if request.method=='POST':
		firm=productform(request.POST)
		if firm.is_valid():
			firm.save()

			return redirect(display)

	firm=productform()
	data=products.objects.all()
	context={'firm':firm , 'data':data}
	return render(request,'home.html',context)

def display(request):
	data=products.objects.all()
	return render(request,'display.html',{'data':data})

def delete(request,id):
	data=get_object_or_404(products,pk=id)
	data.delete()
	return redirect(display)
	#return render(request,'delete.html',{'data':data})