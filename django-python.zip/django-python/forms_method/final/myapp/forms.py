from django.db import models
from.models import products
from django import forms

class productform(forms.ModelForm):
	class Meta:
		model=products
		fields='__all__'