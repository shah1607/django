from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpRequest
from.models import usermodel
from.forms import signup,logins

def home(request):
	if request.method=='POST':
		users=signup(request.POST)
		if users.is_valid():
			users.save()
	#return redirect(login)
	
	users=signup()
	data=usermodel.objects.all()
	context={'users':users,'data':data}
	return render(request,'home.html',context)

def login(request):
	userlogin=logins()
	data=usermodel.objects.all()
	context={'userlogin':userlogin,'data':data}
	return render(request,'login.html',context)

def check(request):
	uname=request.POST.get('uname')
	pwd=request.POST.get('pwd')

	data=usermodel.objects.all()

	for d in data:
		if(d.uname==uname and d.pwd==pwd):
			return redirect(home)
		# else:
		# 	return HttpResponse("Wrong Username or Password")
