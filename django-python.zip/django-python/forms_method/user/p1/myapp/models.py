from django.db import models

# Create your models here.
class usermodel(models.Model):
	uname=models.CharField(max_length=50)
	pwd=models.CharField(max_length=50)
	Email=models.EmailField(max_length=50)
	contact=models.IntegerField()

	def __str__(self):
		return self.uname

#serializer

#POST ------- CREATE NEW
#GET -------- DISPLAY ALL STYDENT
#PUT ---------- EDIT

#URL
#router Application