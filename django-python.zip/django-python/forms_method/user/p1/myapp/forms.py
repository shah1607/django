from django import forms
from django.contrib import admin
from.models import usermodel


class signup(forms.ModelForm):
	class Meta:
		model=usermodel
		fields='__all__'

class logins(forms.ModelForm):
	class Meta:
		model=usermodel
		fields=['uname','pwd']