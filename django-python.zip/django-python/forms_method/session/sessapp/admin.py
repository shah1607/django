from django.contrib import admin
from.models import images,books
# Register your models here.
admin.site.register(images)
admin.site.register(books)