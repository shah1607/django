from django.contrib import admin
from.models import images,books
from django import forms
# Register your models here.
class imageform(forms.ModelForm):
	class Meta:
		model=images
		fields='__all__'

class bookform(forms.ModelForm):
	class Meta:
		model=books
		fields='__all__'