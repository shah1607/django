from django.shortcuts import render,redirect
from.models import images,books
from.forms import imageform,bookform
# Create your views here.
def home(request):
	if request.method=='POST':
		iform=imageform(data=request.POST)
		iform.is_valid()
		iname=iform.cleaned_data.get('iname')
		iprice=iform.cleaned_data.get('iprice')

		if iname=='admin':
			request.session['iname']=iname
			return redirect(addbook)
	else:
		iform=imageform()
		return render(request,'home.html',{'iform':iform})


def addbook(request):
	if request.method=='POST':
		bform=bookform(request.POST)
		if bform.is_valid():
			bform.save()
		return redirect(display)

	bform=bookform()
	data=books.objects.all()
	context={'bform':bform,'data':data}
	return render(request,'addbook.html',context)

def display(request):
	iname=request.session.get('iname')
	if iname:
		data=books.objects.all()
		return render(request,'display.html',{'data':data})
	return redirect(home)	