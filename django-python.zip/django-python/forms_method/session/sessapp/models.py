from django.db import models

# Create your models here.
class images(models.Model):
	iname=models.CharField(max_length=50)
	iprice=models.IntegerField()

	def __str__(self):
		return self.iname

class books(models.Model):
	bname=models.CharField(max_length=50)
	bprice=models.IntegerField()

	def __str__(self):
		return self.bname