from django import forms
from.models import userss,events

class userform(forms.ModelForm):
	class Meta:
		model=userss
		fields='__all__'

class loginform(forms.ModelForm):
	class Meta:
		model=userss
		fields=['uname','pwd']

class eform(forms.ModelForm):
	class Meta:
		model=events
		fields='__all__'