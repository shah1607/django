from django.db import models

# Create your models here.
class userss(models.Model):
	uname=models.CharField(max_length=50)
	ename=models.EmailField(max_length=50)
	pwd=models.IntegerField()

	def __str__(self):
		return self.uname

class events(models.Model):
	eename=models.CharField(max_length=50)
	eorg=models.CharField(max_length=50)
	eprice=models.IntegerField()

	def __str__(self):
		return self.eename