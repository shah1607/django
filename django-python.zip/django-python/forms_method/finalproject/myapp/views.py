from django.shortcuts import render,redirect,get_object_or_404
from.models import userss,events
from.forms import userform,loginform,eform
# Create your views here.

def landing(request):
	return render(request,'landing.html')
	
def home(request):
	if request.method=='POST':
		firm=userform(request.POST)
		if firm.is_valid():
			firm.save()
		return redirect(login)
	
	firm=userform()
	data=userss.objects.all()
	context={'firm':firm,'data':data}
	return render(request,'home.html',context)

def login(request):
	uform=loginform()
	data=userss.objects.all()
	context={'uform':uform,'data':data}
	return render(request,'login.html',context)

def check(request):
	uname=request.POST.get('uname')
	pwd=request.POST.get('pwd')
	
	data=userss.objects.all()

	for d in data:
		if(d.uname==uname and d.pwd==pwd):
			return redirect(display)

		# else:
			# return render(request,'login.html')

def display(request):
	data=events.objects.all()
	return render(request,'display.html',{'data':data})

def addinfo(request):
	if request.method=='POST':
		event=eform(request.POST)
		if event.is_valid():
			event.save()
		return redirect(display)
	
	event=eform()
	data=events.objects.all()
	context={'event':event,'data':data}
	return render(request,'add.html',context)

def delete(request,id):
	data=get_object_or_404(events,pk=id)
	data.delete()
	return redirect(display)
