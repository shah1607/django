from django.contrib import admin
from.models import userss,events
# Register your models here.

admin.site.register(userss)
admin.site.register(events)