from django.shortcuts import render,redirect
from.forms import Loginform,signup
# Create your views here.
def login(request):
	lform=Loginform()
	return render(request,'login.html',{'form':lform})

def signup(request):
	regform=signup()
	return render(request,'signup.html',{'regform':regform})