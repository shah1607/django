from django.db import models

# Create your models here.
#create form without using models