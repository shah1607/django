from django.shortcuts import render,redirect
from.models import phonesmodel
from.forms import phoneform
# Create your views here.

def home(request):
	if request.method=='POST':
		phnform=phoneform(data=request.POST)
		phnform.is_valid()
		phname=phnform.cleaned_data.get('phname')
		phbrand=phnform.cleaned_data.get('phbrand')

		if phname=='phname':
			request.session['phname']=phname
			return redirect(home)

		else:
			phnform=phoneform()
			return render(request,'phone.html',{'phnform':phnform})