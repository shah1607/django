from django.db import models

# Create your models here.
class phonesmodel(models.Model):
	phname=models.CharField(max_length=50)
	phbrand=models.CharField(max_length=50)

	def __str__(self):
		return self.pname