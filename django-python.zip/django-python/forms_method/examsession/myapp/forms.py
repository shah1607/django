from django.contrib import admin
from.models import phonesmodel
from django import forms
# Register your models here.
class phoneform(forms.ModelForm):
	class Meta:
		model=phonesmodel
		fields='__all__'