from django.shortcuts import render,redirect,get_object_or_404
from django.http import HttpResponse,HttpRequest
from.forms import userform,loginform
from.models import users
# Create your views here.
def home(request):
	if request.method=='POST':
		formss=userform(request.POST)
		if formss.is_valid():
			formss.save()

		return redirect(login)

	formss=userform()
	data=users.objects.all()
	context={'formss':formss,'data':data}
	return render(request,'home.html',context)

def login(request):
	formlogin=loginform()
	data=users.objects.all()
	context={'formlogin':formlogin,'data':data}
	return render(request,'user.html',context)

def check(request):
	uname=request.POST.get('uname')
	pwd=request.POST.get('pwd')

	data=users.objects.all()

	for d in data:
		if(d.uname==uname and d.pwd==pwd):
			return redirect(display)

def display(request):
	data=users.objects.all()
	return render(request,'display.html',{'data':data})


def update(request,id):
	#id=request.POST.get('id')
	data=get_object_or_404(users,pk=id)#kaya models mathi id lebva ni.....to users model
	if request.method=='POST':
		edit=userform(request.POST,instance=data)
		edit.save()
		return redirect(display)
	else:	
		edit=userform(instance=data)
	return render(request,'update.html',{'edit':edit})

# def updatedata(request):
# 	id=request.GET['id']
# 	data=users.objects.get(id=id)

def delete(request,id):
	data=get_object_or_404(users,pk=id)
	data.delete()
	return render(request,'delete.html')