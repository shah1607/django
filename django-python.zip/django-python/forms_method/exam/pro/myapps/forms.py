from django.test import TestCase
from django import forms
from.models import users 
# Create your tests here.
class userform(forms.ModelForm):
	class Meta:
		model=users
		fields='__all__'

class loginform(forms.ModelForm):
	class Meta:
		model=users
		fields=['uname','pwd']