from django.db import models

# Create your models here.
class info(models.Model):
	fname=models.CharField(max_length=50)
	lname=models.CharField(max_length=50)
	email=models.EmailField()
	contact=models.IntegerField()

	def __str__(self):
		return self.fname