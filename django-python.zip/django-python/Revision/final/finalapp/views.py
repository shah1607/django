from django.shortcuts import render,redirect
from.models import final
# Create your views here.
def  home(request):
	return render(request,'home.html')

def student(request):
	return render(request,'form.html')

def savedata(request):
	name=request.POST.get("name")
	lname=request.POST.get("lname")
	ps=final(name=name,lname=lname)
	ps.save()
	return redirect (display)

def display(request):
	data=final.objects.all()
	return render(request,'display.html',{'data':data})

def update(request):
	id=request.GET['id']
	data=final.objects.get(id=id)
	return render(request,'update.html',{'data':data})

def updatedata(request):
	id=request.POST['id']
	data=final.objects.get(id=id)
	data.name=request.POST['name']
	data.lname=request.POST['lname']

	data.save()
	return redirect(display)

def delete(request):
	id=request.GET['id']
	data=final.objects.get(id=id)
	data.delete()
	return redirect(display)

def search(request):
	search=request.POST.get("search")
	data=final.objects.filter(name=search) 
	return render(request,'search.html',{'data':data})