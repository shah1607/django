from django.contrib import admin
from.models import usermodel,productmodel
# Register your models here.
admin.site.register(usermodel)
admin.site.register(productmodel)
