from django.shortcuts import render,redirect,get_object_or_404
from.models import usermodel,productmodel
from.forms import userform,loginform,productform
# Create your views here.

def landing(request):
	return render(request,'landing.html')

def signup(request):
	if request.method=='POST':
		firm=userform(request.POST)
		if firm.is_valid():
			firm.save()
		return redirect(login)

	firm=userform()
	data=usermodel.objects.all()
	context={'firm':firm,'data':data}
	return render(request,'signup.html',context)

def login(request):
	firm1=loginform()
	data=usermodel.objects.all()
	context={'firm1':firm1,'data':data}
	return render(request,'login.html',context)

def check(request):
	name=request.POST.get('name')
	pwd=request.POST.get('pwd')

	data=usermodel.objects.all()

	for d in data:
		if(d.name==name and d.pwd==pwd):
			return redirect(productforms)

def productforms(request):
	if request.method=='POST':
		fform=productform(request.POST)
		if fform.is_valid():
			fform.save()
		return redirect(display)

	fform=productform()
	data=productmodel.objects.all()
	context={'fform':fform,'data':data}
	return render(request,'pform.html',context)

def display(request):
	data=productmodel.objects.all()
	return render(request,'display.html',{'data':data})

def delete(request,id):
	data=get_object_or_404(productmodel,pk=id)
	data.delete()
	return redirect(display)

def update(request,id):
	data=get_object_or_404(productmodel,pk=id)
	if request.method=='POST':
		aform=productform(request.POST,instance=data)
		aform.save()
		return redirect(display)

	else:
		aform=productform(instance=data)
		return render(request,'update.html',{'aform':aform})