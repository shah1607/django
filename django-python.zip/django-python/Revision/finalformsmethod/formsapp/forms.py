from django.contrib import admin
from.models import usermodel,productmodel
from django import forms
# Register your models here.
class userform(forms.ModelForm):
	class Meta:
		model=usermodel
		fields='__all__'

class loginform(forms.ModelForm):
	class Meta:
		model=usermodel
		fields=['name','pwd']

class productform(forms.ModelForm):
	class Meta:
		model=productmodel
		fields='__all__'
		
