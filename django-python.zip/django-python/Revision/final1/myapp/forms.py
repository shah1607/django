from django.contrib import admin
from.models import pros
from django import forms
# Register your models here.
class uform(forms.ModelForm):
	class Meta:
		model=pros
		fields='__all__'