from django.shortcuts import render,redirect,get_object_or_404
from.models import pros
from.forms import uform
# Create your views here.
def home(request):
	if request.method=='POST':
		firm=uform(request.POST)
		if firm.is_valid():
			firm.save()
		return redirect(display)

	firm=uform()
	data=pros.objects.all()
	context={'firm':firm,'data':data}
	return render(request,'home.html',context)

def display(request):
	data=pros.objects.all()
	return render(request,'display.html',{'data':data})

def update(request,id):
	data=get_object_or_404(pros,pk=id)
	if request.method=='POST':
		firm1=uform(request.POST,instance=data)
		firm1.save()
		return redirect(display)

	else:
		firm1=uform(instance=data)
		return render(request,'update.html',{'firm1':firm1})
def delete(request,id):
	data=get_object_or_404(pros,pk=id)
	data.delete()
	return redirect(display)
