from django.contrib import admin
from.models import pros
# Register your models here.
admin.site.register(pros)