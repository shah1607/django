from django.contrib import admin
from.models import cars
# Register your models here.
admin.site.register(cars)