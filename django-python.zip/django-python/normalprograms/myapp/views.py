from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpRequest
from.models import cars
# Create your views here.
def Home(request):
	return render(request,'home.html')

def add(request):
	return render(request,'add.html')

def savedata(request):
	cname=request.GET.get('cname')
	cbrand=request.GET.get('cbrand')
	ccolor=request.GET.get('ccolor')
	cprice=request.GET.get('cprice')
	c=cars(cname=cname,cbrand=cbrand,ccolor=ccolor,cprice=cprice)
	c.save()
	return redirect(Home)

def display(request):
	data=cars.objects.all()
	return render(request,'display.html',{'data':data})

def search(request):
	search=request.GET['search']
	data=cars.objects.filter(cname=search) | cars.objects.filter(cbrand=search)
	return render(request,'searchlist.html',{'data':data})

def searchlist(request):
	return render(request,'searchlist.html')