from django.db import models

# Create your models here.
class cars(models.Model):
	cname=models.CharField(max_length=50)
	cbrand=models.CharField(max_length=50)
	ccolor=models.CharField(max_length=50)
	cprice=models.IntegerField()

	def __str__(self):
		return self.cname