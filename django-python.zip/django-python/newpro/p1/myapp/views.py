from django.shortcuts import render,redirect
from rest_framework import viewsets
from rest_framework import permissions
from.serializers import userserializer
from.models import project 

# Create your views here.
class projectviewset(viewsets.ModelViewSet):
	queryset=project.objects.all()
	serializer_class=userserializer
	permission_classes=[permissions.IsAuthenticated]