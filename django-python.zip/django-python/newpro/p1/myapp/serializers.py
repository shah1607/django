from rest_framework import serializers
from.models import project

# Create your models here.
class userserializer(serializers.HyperlinkedModelSerializer):
	class Meta:
		model=project
		fields='__all__'