from django import forms
from django.contrib import admin
from.models import product

class Productform(forms.ModelForm):#inherit Model from

	class Meta:
		model=product
		fields='__all__'

class userform(forms.ModelForm):
	class Meta:
		model=signup
		fields=['username','password']