from django.db import models

# Create your models here.
class product(models.Model):
	pname=models.CharField(max_length=50)
	pprice=models.IntegerField()
	pcategories=models.CharField(max_length=50)
	pdesc=models.CharField(max_length=50)

	def __str__(self):
		return self.pname

class signup(models.Model):
	uname=models.CharField(max_length=50)
	fname=models.CharField(max_length=50)
	lname=models.CharField(max_length=50)
	password=models.IntegerField()

	def __str__(self):
		return self.uname