from django.shortcuts import render,redirect
from.models import product
from.forms import Productform

def home(request):
	if request.method=="POST":
		pform=Productform(request.POST)
		if pform.is_valid():
			pform.save()

		return redirect(home)

	pform=Productform()
	data=product.objects.all()
	context={'pform':pform,'data':data}
	return render(request,'home.html',context)

def login(request):
	return render(request,'login.html')