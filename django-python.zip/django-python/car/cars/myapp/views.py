from django.shortcuts import render
from django.http import HttpResponse,HttpRequest 
from myapp.models import Cars
# Create your views here.
def web(request):
	return render(request,'landing.html')

def addcar(request):
	return render(request,'form.html')

def savedata(request):
	cname=request.GET.get('cname')
	cprice=request.GET.get('cprice')
	comp=request.GET.get('comp')
	color=request.GET.get('color')
	p=Cars(cname=cname,cprice=cprice,comp=comp,color=color)
	p.save()
	data=Cars.objects.all()
	return render(request,'display.html',{'data':data})

def display(request):
	data=Cars.objects.all()
	return render(request,'display.html',{'data':data})