from django.shortcuts import render, redirect
from .models import Register
# Create your views here.

def register(request):
	if request.method=='POST':
		fname=request.POST.get("fname")
		lname=request.POST.get("lname")
		email=request.POST.get("email")
		Pas=request.POST.get("Pas")
		cpas=request.POST.get("cpas")

		if Pas==cpas:

			query=Register(fname=fname,lname=lname,email=email,Pas=Pas,cpas=cpas)
			query.save()
		else:

			pass
	return render(request,'signup.html')

def login(request):
	if request.method == "POST":
		email=request.POST.get("email")
		Pas=request.POST.get("Pas")

		checkuser=Register.objects.filter(email=email,Pas=Pas)
		if checkuser:
			request.session['email']=email
			return redirect('index')
		else:
			pass
	return render(request,'login.html')

def index(request):

	if 'email' in request.session:
		data = Register.objects.all()
		return render(request, 'index.html', {'data': data})
	else:
		return redirect('login')

	return render(request,'index.html')

def delete(request, id):
	query = Register.objects.get(id=id)
	query.delete()
	return render(request, 'index.html')

def edit(request,id):
	if 'email' in request.session:
		data = Register.objects.get(id=id)
		return render(request, 'edit.html', {'data': data})
	else:
		return redirect('signup')

def update(request, id):
	if request.method == 'POST':
		fname = request.POST.get("fname")
		lname = request.POST.get("lname")
		Pas = request.POST.get("Pas")
		cpas = Pas

		if Pas == cpas:
			obj = Register.objects.get(id=id)
			obj.id = id
			obj.fname = fname
			obj.lname = lname
			obj.Pas = Pas
			obj.cpas = cpas
			obj.save()
		else:
			return redirect('/edit')

		return redirect('index')
	return render(request, 'edit.html')