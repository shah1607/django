from django.shortcuts import render
from django.http import HttpRequest,HttpResponse

def simple(request):
	return HttpResponse("Hello")
# Create your views here.
