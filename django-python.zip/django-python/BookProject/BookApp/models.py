from django.db import models

# Create your models here.
class BookModel(models.Model):
	Book_Name=models.CharField(max_length=30)
	Book_Price=models.CharField(max_length=30)
	Book_Author=models.CharField(max_length=30)

	def __str__(self):
		return self.Book_Name
class UserModel(models.Model):
	name=models.CharField(max_length=30)
	username=models.CharField(max_length=30)
	password=models.CharField(max_length=30)

	def __str__(self):
		return self.name