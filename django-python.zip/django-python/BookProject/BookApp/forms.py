from django import forms
from .models import BookModel,UserModel
# Create your forms here.
class BookForm(forms.ModelForm):
	class Meta:
		model=BookModel
		fields='__all__'

class LoginForm(forms.ModelForm):
	class Meta:
		model=UserModel
		fields=['username','password']
		