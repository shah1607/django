from django.contrib import admin
from.models import st
# Register your models here.
admin.site.register(st)