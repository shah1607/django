from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpRequest
from myapp.models import product

# Create your views here.
def landing(request):
	return render(request,'landing.html')

def form(request):
	return render(request,'form.html')
	
def savedata(request):
	name=request.GET.get('name')
	pbrand=request.GET.get('pbrand')
	price=request.GET.get('price')
	stock=request.GET.get('stock')
	p=product(name=name,pbrand=pbrand,price=price,stock=stock)
	p.save()
	return redirect(landing)

def display(request):
	data=product.objects.all()
	return render(request,'display.html',{'data':data})

def display1(request):
	return render(request,'display1.html')

	#data=product.objects.filter(price__lte = 20000)
	#data.filter(price<=20000)
	

def search(request):
	search=request.GET['search']
	data=product.objects.filter(name=search) | product.objects.filter(pbrand=search)
	#data=product.objects.filter(pbrand=search)
	return render(request,'display1.html',{'data':data})

	#data.filter(price<=20000)
	#return render(request,'display1.html',{'data':data})


def buys(request):
	id=request.GET['id']
	data=product.objects.get(id=id)
	data.stock=data.stock-1
	data.save()
	return redirect(display)