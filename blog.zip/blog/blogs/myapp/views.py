from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpRequest
from myapp.models import Blogs
# Create your views here.
def index(request):
	return render(request,'index.html')
def form(request):
	return render(request,'form.html')

def addform(request):
	title=request.GET['title']
	desc=request.GET['desc']
	blg=Blogs(title=title,desc=desc)
	blg.save()
	#data=Blogs.objects.all()
	#return render(request,'display.html',{'data':data})
	return redirect(display)

def display(request):
	data=Blogs.objects.all()
	return render(request,'display.html',{'data':data})

def update(request):
	id=request.GET['id']
	data=Blogs.objects.get(id=id)
	return render(request,'update.html',{'data':data})

def updatedata(request):
	id=request.GET['id']
	data=Blogs.objects.get(id=id)
	data.title=request.GET['title']
	data.desc=request.GET['desc']
	
	data.save()
	data=Blogs.objects.all()
	# return render(request,'display.html',{'data':data})
	return redirect(display)
	

def delete(request):
	id=request.GET['id']
	data=Blogs.objects.get(id=id)
	data.delete()
	# data=Blogs.objects.all()
	# return render(request,'display.html',{'data':data})
	return redirect(display)

def querys(request):
	
		data=Blogs.objects.filter(title ='pythomn')
		return render(request,'dis.html',{'Data':data})
